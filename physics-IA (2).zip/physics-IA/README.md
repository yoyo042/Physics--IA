# Physics IA: release angle of a pendulum and spring extension

Data, code and figures for the IB Physics IA on how the release angle of a pendulum
(a bob on a spring) affects the extension of the spring at the bottom of the swing.

## Contents

| Path | What it is |
|---|---|
| `data/raw_data.csv` | Raw trials: greatest spring length (cm), five trials at each angle from 20 to 70 degrees |
| `data/processed_data.csv` | Means, uncertainties, extension e and y = e(L + 2e) (written by `make_graphs.py`) |
| `data/energy_table.csv` | GPE, EPE and KE at each angle (written by `energy_graphs.py`) |
| `src/make_graphs.py` | Processes the raw data, draws Graph 1 and Graph 2, finds the gradients |
| `src/energy_graphs.py` | Energy table, Graph 3 and Graph 4 |
| `src/force_diagrams.py` | Figure 3: force diagrams |
| `figures/` | Output images |

## Run (from the repository root)

```
pip install -r requirements.txt
python src/make_graphs.py
python src/energy_graphs.py
python src/force_diagrams.py
```

## Method summary

- Mass 20 g, rest length of the spring with the bob hanging L = 19.3 cm; extension e = (length) - L.
- Model with a constant spring constant k: e(L + 2e) = (2mgL/k)(1 - cos theta), so e(L + 2e) against (1 - cos theta) is a straight line.
- Share of the energy stored in the spring: EPE / GPE = e / (L + 2e) (k cancels).
- Length uncertainty = half-range of five trials (or 0.1 cm ruler uncertainty if larger); angle uncertainty = 1 degree.
- Steepest and shallowest gradients are found by linear programming (largest and smallest gradient of a line that passes through every error bar).

## Figures

### Graph 1: spring length against release angle
![Graph 1](figures/graph1_length_vs_angle.png)

### Graph 2: e(L + 2e) against (1 - cos θ)
![Graph 2](figures/graph2_linearised.png)

### Graph 3: how the energy released is shared
![Graph 3](figures/graph3_energy_stacked.png)

### Graph 4: energy conversion
![Graph 4](figures/graph4_energy_lines.png)

### Figure 3: force diagrams
![Figure 3](figures/figure3_force_diagrams.png)
