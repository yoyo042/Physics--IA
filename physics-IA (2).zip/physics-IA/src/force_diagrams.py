# force_diagrams.py - Figure 3: force diagrams for the bob
# (a) at the release position, (b) at the lowest point.
# Run from the repository root:  python src/force_diagrams.py
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle


def arrow(ax, start, end, colour):
    ax.annotate('', xy=end, xytext=start, arrowprops=dict(arrowstyle='-|>', color=colour, lw=2.2))


def label(ax, xy, text, colour, ha='left'):
    ax.text(xy[0], xy[1], text, color=colour, fontsize=12, ha=ha, va='center')


def spring(ax, x, y_top, y_bottom, coils=8, amp=0.18):
    ys = np.linspace(y_top, y_bottom, coils * 2 + 1)
    xs = x + amp * np.array([0] + [(-1) ** i for i in range(coils * 2 - 1)] + [0])
    ax.plot(xs, ys, color='k', lw=1.6)


fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 6.5))

# ---------- (a) release position: bob held at angle theta, momentarily at rest ----------
theta = np.radians(40)
L = 4.0
pivot = np.array([0.0, 0.0])
bob = np.array([L * np.sin(theta), -L * np.cos(theta)])
to_pivot = (pivot - bob) / L                                   # unit vector along the spring, towards the pivot
to_bottom = np.array([-np.cos(theta), -np.sin(theta)])         # unit vector perpendicular to the spring, towards the lowest point
W = 2.0                                                        # length of the weight arrow
a1.plot([-1, 1], [0.1, 0.1], color='k', lw=4)                  # support
a1.plot([0, 0], [0, -L], ':', color='gray')                    # vertical
a1.plot([pivot[0], bob[0]], [pivot[1], bob[1]], color='k', lw=1.5)
a1.add_patch(Circle(bob, 0.18, color='tab:gray', zorder=3))
weight_tip = bob + np.array([0, -W])
along_tip = bob - W * np.cos(theta) * to_pivot                 # mg cos(theta): along the spring, away from the pivot
across_tip = bob + W * np.sin(theta) * to_bottom               # mg sin(theta): perpendicular to the spring
arrow(a1, bob, weight_tip, 'tab:red')                          # weight mg
arrow(a1, bob, along_tip, 'tab:red')                           # component mg cos(theta)
arrow(a1, bob, across_tip, 'tab:red')                          # component mg sin(theta)
a1.plot([weight_tip[0], along_tip[0]], [weight_tip[1], along_tip[1]], '--', color='gray', lw=1)
a1.plot([weight_tip[0], across_tip[0]], [weight_tip[1], across_tip[1]], '--', color='gray', lw=1)
arrow(a1, bob, bob + W * np.cos(theta) * to_pivot, 'tab:blue')  # spring force T = mg cos(theta) (bob at rest, no acceleration along the spring)
label(a1, weight_tip + np.array([0.15, 0]), 'mg', 'tab:red')
label(a1, along_tip + np.array([0.15, -0.15]), 'mg cos θ', 'tab:red')
label(a1, across_tip + np.array([-0.15, -0.15]), 'mg sin θ', 'tab:red', ha='right')
label(a1, bob + W * np.cos(theta) * to_pivot + np.array([-0.2, 0]), 'T', 'tab:blue', ha='right')
label(a1, (0.2, -1.0), 'θ', 'k')
a1.set_title('(a) At the release position (spring drawn as a line)')
a1.set_aspect('equal')
a1.axis('off')
a1.set_xlim(-3.5, 4.5)
a1.set_ylim(-7.0, 0.8)

# ---------- (b) lowest point: spring above the bob, bob moving in a circle ----------
a2.plot([-1, 1], [0.1, 0.1], color='k', lw=4)
spring(a2, 0, -0.2, -3.2)
a2.plot([0, 0], [0, -0.2], color='k', lw=1.5)
a2.plot([0, 0], [-3.2, -3.7], color='k', lw=1.5)
bob_b = np.array([0, -3.9])
a2.add_patch(Circle(bob_b, 0.22, color='tab:gray', zorder=3))
arrow(a2, bob_b, bob_b + np.array([0, 2.4]), 'tab:blue')       # spring force T = mg + ke, upwards
arrow(a2, bob_b, bob_b + np.array([0, -1.4]), 'tab:red')       # weight mg, downwards
arrow(a2, (1.0, -5.0), (1.0, -4.2), 'tab:green')               # resultant force, upwards
label(a2, bob_b + np.array([-0.3, 1.9]), 'T = mg + ke', 'tab:blue', ha='right')
label(a2, bob_b + np.array([-0.3, 1.4]), '(spring force)', 'tab:blue', ha='right')
label(a2, bob_b + np.array([0.3, -1.4]), 'mg', 'tab:red')
label(a2, (1.2, -4.8), 'resultant force = T − mg = mv²/ℓ', 'tab:green')
label(a2, (1.2, -5.3), '(upwards, towards the pivot; ℓ = spring length)', 'tab:green')
label(a2, (0.45, -2.0), 'spring', 'k')
label(a2, (0.45, -2.4), '(extension e)', 'k')
a2.set_title('(b) At the lowest point')
a2.set_aspect('equal')
a2.axis('off')
a2.set_xlim(-2.5, 6.5)
a2.set_ylim(-6.0, 0.8)

fig.suptitle('Figure 3: Force diagrams for the bob', fontsize=13)
fig.tight_layout()
fig.savefig('figures/figure3_force_diagrams.png', dpi=200)
