# make_graphs.py - processes the raw trials and draws Graph 1 and Graph 2
# Run from the repository root:  python src/make_graphs.py
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import linprog
from scipy.stats import linregress

L = 19.3            # cm, spring length with the bob hanging at rest (pendulum length)
DL = 0.1            # cm, uncertainty in L
RULER = 0.1         # cm, ruler uncertainty
DTHETA = 1.0        # degrees, protractor uncertainty

# ---------- 1. Process the raw data ----------
rows = list(csv.DictReader(open('data/raw_data.csv')))
theta = np.array([float(r['angle_deg']) for r in rows])
trials = np.array([[float(r[f'trial{i}_cm']) for i in range(1, 6)] for r in rows])
mean = trials.mean(axis=1)                                   # mean length
half_range = (trials.max(axis=1) - trials.min(axis=1)) / 2   # random uncertainty
d_len = np.maximum(half_range, RULER)                        # use the larger of the two
e = mean - L                                                 # extension beyond the rest length
d_e = d_len + DL                                             # uncertainties add in a subtraction
c = 1 - np.cos(np.radians(theta))                            # 1 - cos(theta)
d_c = np.sin(np.radians(theta)) * np.radians(DTHETA)         # uncertainty in 1 - cos(theta)
y = e * (L + 2 * e)                                          # y = e(L + 2e), in cm^2
d_y = (L + 4 * e) * d_e                                      # uncertainty in y

with open('data/processed_data.csv', 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['angle_deg', 'mean_length_cm', 'abs_unc_length_cm', 'extension_cm', 'abs_unc_extension_cm',
                'one_minus_cos', 'abs_unc_one_minus_cos', 'y_cm2', 'abs_unc_y_cm2'])
    for i in range(len(theta)):
        w.writerow([int(theta[i]), round(mean[i], 2), round(d_len[i], 2), round(e[i], 2), round(d_e[i], 2),
                    round(c[i], 4), round(d_c[i], 4), round(y[i], 1), round(d_y[i], 1)])

# ---------- 2. Gradients ----------
fit = linregress(c, y)                                       # best-fit straight line y = gradient * c + intercept


def extreme_gradient(sign):
    # steepest (sign = -1) or shallowest (sign = +1) straight line that still passes through every y error bar
    # variables: gradient a and intercept b; constraints: y - d_y <= a*c + b <= y + d_y
    A = np.vstack([np.column_stack([c, np.ones_like(c)]), -np.column_stack([c, np.ones_like(c)])])
    b = np.concatenate([y + d_y, -(y - d_y)])
    res = linprog([sign, 0], A_ub=A, b_ub=b, bounds=[(None, None), (None, None)])
    return res.x


a_min, b_min = extreme_gradient(+1)
a_max, b_max = extreme_gradient(-1)
grad_unc = (a_max - a_min) / 2

# ---------- 3. Graph 1: length against angle, with the model curve ----------
tt = np.linspace(15, 75, 200)
ct = 1 - np.cos(np.radians(tt))
e_model = (-L + np.sqrt(L**2 + 8 * fit.slope * ct)) / 4      # solves 2e^2 + L e - gradient*(1 - cos) = 0
fig, ax = plt.subplots(figsize=(8, 5.5))
ax.errorbar(theta, mean, yerr=d_len, xerr=DTHETA, fmt='o', color='k', ecolor='red', capsize=4,
            label='Mean length ± uncertainty')
ax.plot(tt, L + e_model, color='tab:blue', label='Model with one constant (fitted gradient)')
ax.set_xlabel('Release angle θ (°)')
ax.set_ylabel('Spring length ℓ (cm)')
ax.set_title('Graph 1: Spring length against release angle')
ax.grid(alpha=0.3)
ax.legend()
fig.tight_layout()
fig.savefig('figures/graph1_length_vs_angle.png', dpi=200)
plt.close(fig)

# ---------- 4. Graph 2: y = e(L + 2e) against (1 - cos theta) ----------
xm = np.linspace(0, c.max() + 0.05, 100)
fig, ax = plt.subplots(figsize=(8, 5.5))
ax.errorbar(c, y, yerr=d_y, xerr=d_c, fmt='o', color='k', ecolor='red', capsize=4, label='Data ± uncertainty')
ax.plot(xm, fit.slope * xm + fit.intercept, color='tab:blue',
        label=f'Best fit: gradient = {fit.slope:.0f} cm²')
ax.plot(xm, a_max * xm + b_max, '--', color='tab:green', label=f'Steepest line: gradient = {a_max:.0f} cm²')
ax.plot(xm, a_min * xm + b_min, '--', color='tab:orange', label=f'Shallowest line: gradient = {a_min:.0f} cm²')
ax.set_xlim(0, c.max() + 0.05)
ax.set_xlabel('1 − cos θ  (no unit)')
ax.set_ylabel('e(L + 2e)  (cm²)')
ax.set_title('Graph 2: e(L + 2e) against (1 − cos θ)')
ax.grid(alpha=0.3)
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig('figures/graph2_linearised.png', dpi=200)
plt.close(fig)

print('theta       :', theta)
print('mean length :', np.round(mean, 2))
print('uncertainty :', np.round(d_len, 2))
print('extension e :', np.round(e, 2), '+/-', np.round(d_e, 2))
print('1 - cos     :', np.round(c, 4), '+/-', np.round(d_c, 4))
print('y = e(L+2e) :', np.round(y, 1), '+/-', np.round(d_y, 1))
print(f'Best-fit gradient = {fit.slope:.1f} cm^2, intercept = {fit.intercept:.1f} cm^2, R^2 = {fit.rvalue**2:.4f}')
print(f'Steepest = {a_max:.1f}, shallowest = {a_min:.1f}, gradient uncertainty = +/- {grad_unc:.1f} cm^2 ({100 * grad_unc / fit.slope:.0f}%)')
