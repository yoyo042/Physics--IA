# energy_graphs.py - energy conversion table and Graphs 3 and 4
# Run after make_graphs.py, from the repository root:  python src/energy_graphs.py
# Energy released by the swing:   GPE = m g L (1 - cos theta)
# Share stored in the spring:     EPE / GPE = e / (L + 2e)     (the spring constant k cancels)
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

M = 0.020      # kg
G = 9.81       # m/s^2
L = 0.193      # m
DL = 0.001     # m

rows = list(csv.DictReader(open('data/processed_data.csv')))
theta = np.array([float(r['angle_deg']) for r in rows])
e = np.array([float(r['extension_cm']) for r in rows]) / 100          # m
d_e = np.array([float(r['abs_unc_extension_cm']) for r in rows]) / 100
c = np.array([float(r['one_minus_cos']) for r in rows])

gpe = M * G * L * c                          # energy released by the swing (J)
share = e / (L + 2 * e)                      # fraction stored as elastic potential energy
d_share = L * d_e / (L + 2 * e) ** 2         # uncertainty in that fraction
epe = share * gpe
ke = gpe - epe

with open('data/energy_table.csv', 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['angle_deg', 'GPE_J', 'EPE_J', 'KE_J', 'EPE_percent_of_GPE', 'abs_unc_percent'])
    for i in range(len(theta)):
        w.writerow([int(theta[i]), f'{gpe[i]:.5f}', f'{epe[i]:.5f}', f'{ke[i]:.5f}',
                    round(100 * share[i], 1), round(100 * d_share[i], 1)])
        print(int(theta[i]), f'GPE = {gpe[i]:.5f} J', f'EPE = {epe[i]:.5f} J', f'KE = {ke[i]:.5f} J',
              f'EPE share = {100 * share[i]:.1f} +/- {100 * d_share[i]:.1f} %')

note = 'm = 20 g, L = 19.3 cm; EPE share = e / (L + 2e), independent of k'

fig, ax = plt.subplots(figsize=(8, 5.5))
ax.bar(theta, epe, width=6, color='tab:green', label='Elastic potential energy (EPE)')
ax.bar(theta, ke, width=6, bottom=epe, color='tab:blue', label='Kinetic energy (KE)')
ax.set_xlabel('Release angle θ (°)')
ax.set_ylabel('Energy (J)')
ax.set_title('Graph 3: How the energy released by the swing is shared')
ax.set_xticks(theta)
ax.legend()
ax.grid(axis='y', alpha=0.3)
fig.text(0.5, 0.01, note, ha='center', fontsize=8, color='gray')
fig.tight_layout(rect=(0, 0.03, 1, 1))
fig.savefig('figures/graph3_energy_stacked.png', dpi=200)
plt.close(fig)

fig, ax = plt.subplots(figsize=(8, 5.5))
ax.plot(theta, gpe, 'o-', label='Energy released (GPE)')
ax.plot(theta, epe, 's-', label='Elastic potential energy (EPE)')
ax.plot(theta, ke, '^-', label='Kinetic energy (KE)')
ax.set_xlabel('Release angle θ (°)')
ax.set_ylabel('Energy (J)')
ax.set_title('Graph 4: Energy conversion at different release angles')
ax.grid(alpha=0.3)
ax.legend()
fig.text(0.5, 0.01, note, ha='center', fontsize=8, color='gray')
fig.tight_layout(rect=(0, 0.03, 1, 1))
fig.savefig('figures/graph4_energy_lines.png', dpi=200)
